#!/bin/sh

git submodule foreach --recursive git pull origin master
git pull
