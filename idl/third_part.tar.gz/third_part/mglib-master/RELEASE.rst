Release notes
=============

mglib 1.1.1
-----------

* Added emacs idlwave mode catalog files.


mglib 1.1.0
-----------

* Library (2014) for Exelis VIS Documentation Center


mglib 1.0.0
-----------

* Initial library (2013) for Exelis VIS Documentation Center