int culaClaset(char uplo, int m, int n, IDL_COMPLEX alpha, IDL_COMPLEX beta, IDL_COMPLEX a[], int lda);
int culaZlaset(char uplo, int m, int n, IDL_DCOMPLEX alpha, IDL_DCOMPLEX beta, IDL_DCOMPLEX a[], int lda);
