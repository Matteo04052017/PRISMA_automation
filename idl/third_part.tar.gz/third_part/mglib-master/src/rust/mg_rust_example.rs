extern crate libc;
mod idl_export;


#[no_mangle]
pub extern fn IDL_Load() {
}