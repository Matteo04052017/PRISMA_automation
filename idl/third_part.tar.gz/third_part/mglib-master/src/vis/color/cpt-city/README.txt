This package contains the gradients from the cpt-city
collection. The archive's home is online at

  http://soliton.vm.bytemark.co.uk/pub/cpt-city/

where the most recent version can be found.

The copyright of the gradient files is held by their
authors, and details of these can be found at the
cpt-city site.

