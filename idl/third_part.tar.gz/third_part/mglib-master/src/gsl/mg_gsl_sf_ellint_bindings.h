double gsl_sf_ellint_F(double phi, double k, unsigned int mode);
