double gsl_sf_psi_int(int n);
//int gsl_sf_psi_int_e(int n, gsl_sf_result *result);
double gsl_sf_psi(double x);
//int gsl_sf_psi_e(double x, gsl_sf_result *result);
double gsl_sf_psi_1piy(double y);
//int gsl_sf_psi_1piy_e(double y, gsl_sf_result *result);
