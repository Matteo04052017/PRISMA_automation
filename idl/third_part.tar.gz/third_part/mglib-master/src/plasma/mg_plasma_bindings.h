int PLASMA_Version(int *ver_major, int *ver_minor, int *ver_micro);

int PLASMA_Init(int cores);
int PLASMA_Set(int param, int value);
int PLASMA_Finalize();
